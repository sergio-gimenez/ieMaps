import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MapsService {

  endpoint = 'http://localhost:8000';

  constructor(private http: HttpClient) { }

  public getCosas() {
    const url = this.endpoint;
    const headers = {'Content-Type': 'application/json'};

    return this.http.get(url, {headers});
  }

}
