import { Component, OnInit } from '@angular/core';
import { MapsService } from '../maps.service';


@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  data: any[] = [
    {
      mode: 'WALKING',
      time: '45',
      distance: '3',
      carbonFootprint: 'Cool',
      airQuality: 'Bad',
      instructions: 'Estas son las instrucciones para llegar a tu destino'
    },
    {
      mode: 'BICYCLE',
      time: '15',
      distance: '3',
      carbonFootprint: 'Yaaaaas',
      airQuality: 'Bad',
      instructions: 'Estas son las instrucciones para llegar a tu destino'
    }
  ];



  lat = 41.3851;
  lng = 2.1734;

  constructor(private mapService: MapsService) {}

  ngOnInit() {}

  public getCosas(): void {
    this.mapService.getCosas().subscribe(c => console.log(c));
  }
}