import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-initial-form',
  templateUrl: './initial-form.component.html',
  styleUrls: ['./initial-form.component.css']
})
export class InitialFormComponent implements OnInit {

  submitted= false;

  constructor() { }

  ngOnInit() {
  }

  onSubmit(){
    this.submitted = true;
  }

}
