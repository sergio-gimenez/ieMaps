export class Search {

constructor(
    public origin: string,
    public destination: string,
    public taxi: boolean,
    public ecar: boolean,
    public disabled: boolean
){

}
}
